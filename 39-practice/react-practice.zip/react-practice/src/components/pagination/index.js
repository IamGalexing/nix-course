import { Pagination } from './Pagination'

export { Pagination }
