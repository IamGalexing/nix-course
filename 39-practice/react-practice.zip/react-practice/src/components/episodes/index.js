import { EpisodeDetails } from './EpisodeDetails'
import { EpisodeCard } from './EpisodeCard'

export { EpisodeDetails, EpisodeCard }
