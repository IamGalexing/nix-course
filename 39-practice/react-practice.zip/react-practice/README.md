# How to use this repo

- make a fork of this repo
- clone your own repo to your local machine and open it in VS Code
- you can find a task description in this project issues
- don't forget to install dependecies: `yarn install`
- create a separate branch and make your task
- when you finish a task commit your changes and push your branch
- make a merge request to `main` branch in a web
- when mentor see your results he will give a feedback for your work. He could also leave comments in your merge request
- if you need to make changes do it :). After that push into current branch. Merge request will be updated automatically. Notify you mentor again.

Good Luck! )
