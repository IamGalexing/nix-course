import { CharacterDetails } from './CharacterDetails'
import { CharacterCard } from './CharacterCard'

export { CharacterDetails, CharacterCard }
