## Checklist

If you don't know how to solve the checklist point skip it.

### Common

- [ ] My feature is in separate branch
- [ ] My solution is finished
- [ ] I've squashed all commits in one (my branch has one commit)
- [ ] I run all linters and tests (if exists) on my local machine and have no errors


#### useful links and recomendations

- you can run `yarn lint` locally to check for HTML errors

