import { StarshipsDetails } from './StarshipDetails'
import { StarshipCard } from './StarshipCard'

export { StarshipsDetails, StarshipCard }
