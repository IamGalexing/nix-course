import { detailsLoader } from './detailsLoader'
import { pageLoader } from './pageLoader'

export { detailsLoader, pageLoader }
