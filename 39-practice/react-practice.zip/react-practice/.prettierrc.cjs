module.exports = {
  singleQuote: true,
  trailingComma: 'es5',
  printWidth: 120,
  semi: false,
  tabWidth: 2
}
