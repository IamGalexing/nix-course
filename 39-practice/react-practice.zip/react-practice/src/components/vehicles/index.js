import { VehiclesDetails } from './VehicleDetails'
import { VehicleCard } from './VehicleCard'

export { VehiclesDetails, VehicleCard }
