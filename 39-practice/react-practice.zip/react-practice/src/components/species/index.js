import { SpeciesDetails } from './SpeciesDetails'
import { SpeciesCard } from './SpeciesCard'

export { SpeciesDetails, SpeciesCard }
