export const ROUTES = {
  EPISODES: '/episodes',
  CHARACTERS: '/characters',
  PLANETS: '/planets',
  SPECIES: '/species',
  VEHICLES: '/vehicles',
  STARSHIPS: '/starships',
}
