import { API } from './API'
import { PER_PAGE } from './ItemsPerPage'

export { API, PER_PAGE }
