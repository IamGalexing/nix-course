import { NotFoundPage } from './NotFoundPage'

export { NotFoundPage }
