import { CardDetailsFields } from './CardDetaisFields'

export { CardDetailsFields }
