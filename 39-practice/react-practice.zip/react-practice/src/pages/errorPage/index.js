import { ErrorPage } from './ErrorPage'

export { ErrorPage }
